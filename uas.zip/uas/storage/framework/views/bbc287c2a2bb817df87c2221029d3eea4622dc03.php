

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
    <table>
        <tr>
            Kubis
        </tr>
        <tr>
            <td>
                <img src="https://t-2.tstatic.net/palembang/foto/bank/images/Kubis-atau-Kol.jpg" alt="Kubis" width="300" height="200">
            </td>
            <td>
                Rp 1.000,00
                <br>
                Kubis, kol, kobis, atau kobis bulat (terdiri dari beberapa kelompok kultivar dari Brassica oleracea) adalah tanaman dua tahunan hijau atau ungu berdaun, ditanam sebagai tanaman tahunan sayuran untuk kepala padat berdaunnya. Erat kaitannya dengan tanaman cole lainnya, seperti brokoli, kembang kol, dan kubis brussel, itu diturunkan dari B. oleracea var. oleracea, kubis lapangan liar. Kepala kubis umumnya berkisar 05 hingga 4 kilogram (10 hingga 9 pon), dan dapat berwarna hijau, ungu dan putih. Kubis hijau berkepala keras berdaun halus adalah yang paling umum, dengan kubis merah berdaun halus dan kubis savoy berdaun crinkle dari kedua warna terlihat lebih jarang. Kubis adalah sayuran yang berlapis-lapis. Dalam kondisi hari diterangi matahari panjang seperti yang ditemukan di garis lintang utara di musim panas, kubis dapat tumbuh jauh lebih besar. Beberapa rekor dibahas pada akhir bagian sejarah.
                <br>
                <a href="">buy now</a>
            </td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UAS\uas\resources\views/kubis.blade.php ENDPATH**/ ?>