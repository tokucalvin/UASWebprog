<style>
    .center{
        text-align: center;
        background-color: mediumaquamarine;
    }
</style>
<div class="center">
    <h1>Amazing E-Grocery</h1>
</div><?php /**PATH D:\UAS\uas\resources\views/header.blade.php ENDPATH**/ ?>