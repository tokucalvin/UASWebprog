

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
    <h1>
        <table>
            <tr>
                <td>
                    <a href="/kentang"><img src="http://t1.gstatic.com/licensed-image?q=tbn:ANd9GcR1M89lNmXLBltfEc5TQZJSpcqvZ36vvZyZfpP98EFh-i4Q9X8S8woN6El91b1pZ5Sw" alt="Kentang" width="300" height="200"></a>
                    <br>
                    Kentang
                </td>
                <td>
                    <a href="/wortel"><img src="https://balidirectstore.com/wp-content/uploads/2019/08/Organic-Baby-Carrot.jpg" alt="Wortel" width="300" height="200"></a>
                    <br>
                    Wortel
                </td>
                <td>
                    <a href="/tomat"><img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/tomatoes-1296x728-feature.jpg" alt="Tomat" width="300" height="200"></a>
                    <br>
                    Tomat
                </td>
                <td>
                    <a href="/kangkung"><img src="https://d1vbn70lmn1nqe.cloudfront.net/prod/wp-content/uploads/2021/11/15081555/Manfaat-Makan-Kangkung-untuk-Kecantikan-dan-Kesehatan-01.jpg" alt="Kangkung" width="300" height="200"></a>
                    Kangkung
                </td>
                <td>
                    <a href="/bayam"><img src="https://akcdn.detik.net.id/visual/2018/07/11/cc01493c-6a04-4bea-b33d-3be0086c9f09_169.jpeg?w=650" alt="Bayam" width="300" height="200"></a>
                    <br>
                    Bayam
                </td>
                <td>
                    <a href="/bawangmerah"><img src="https://asset.kompas.com/crops/A1pqv_0Um0AOuA4rMshY5Xg3BAw=/0x0:1000x667/750x500/data/photo/2019/06/06/1393496124.jpg" alt="Bawang Merah" width="300" height="200"></a>
                    <br>
                    Bawang Merah
                </td>
            </tr>
            <tr>
                <td>
                    <a href="/pisang"><img src="https://img.okezone.com/content/2020/05/15/298/2214844/ciri-ciri-pisang-matang-sempurna-bReK2YGBA0.jpg" alt="Pisang" width="300" height="200"></a>
                    <br>
                    Pisang
                </td>
                <td>
                    <a href="/apel"><img src="https://www.astronauts.id/blog/wp-content/uploads/2022/12/Kenali-Jenis-jenis-Buah-Apel-dan-Manfaatnya-1200x900.jpg" alt="Apel" width="300" height="200"></a>
                    <br>
                    Apel
                </td>
                <td>
                    <a href="/anggur"><img src="https://www.ngopibareng.id/images/uploads/2022/2022-02-04/mengenal-13-macam-anggur-dan-manfaatnya-untuk-kesehatan--thumbnail-547" alt="" width="300" height="200"></a>
                    <br>
                    Anggur
                </td>
                <td>
                    <a href="/mangga"><img src="https://images.tokopedia.net/img/cache/500-square/VqbcmM/2021/10/1/4b7810bc-1e1f-4869-a475-f301c413f531.jpg" alt="Mangga" width="300" height="200"></a>
                    <br>
                    Mangga
                </td>
                <td>
                    <a href="/manggis"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Mangosteen1.jpg/1200px-Mangosteen1.jpg" alt="Manggis" width="300" height="200"></a>
                    <br>
                    Manggis
                </td>
                <td>
                    <a href="/kubis"><img src="https://t-2.tstatic.net/palembang/foto/bank/images/Kubis-atau-Kol.jpg" alt="Kubis" width="300" height="200"></a>
                    <br>
                    Kubis
                </td>
            </tr>
        </table>
    </h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UAS\uas\resources\views/home.blade.php ENDPATH**/ ?>