

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
    <table>
        <tr>
            Kangkung
        </tr>
        <tr>
            <td>
                <img src="https://d1vbn70lmn1nqe.cloudfront.net/prod/wp-content/uploads/2021/11/15081555/Manfaat-Makan-Kangkung-untuk-Kecantikan-dan-Kesehatan-01.jpg" alt="Kangkung" width="300" height="200">
            </td>
            <td>
                Rp 7.000,00
                <br>
                Kangkung (kangkung) adalah tumbuhan yang termasuk jenis sayur-sayuran dan ditanam sebagai makanan. Kangkung banyak dijual di pasar-pasar. Kangkung banyak terdapat di kawasan Asia, tempat asalnya tidak diketahui. dan merupakan tumbuhan yang dapat dijumpai hampir di mana-mana terutama di kawasan berair.

Masakan kangkung yang populer adalah cah kangkung bumbu tauco atau terasi, juga di wewarungan terdapat pelecing kangkung lombok
                <br>
                <a href="">buy now</a>
            </td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UAS\uas\resources\views/kangkung.blade.php ENDPATH**/ ?>