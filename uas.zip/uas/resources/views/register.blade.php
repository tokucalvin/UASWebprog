@extends('main')

@section('container')
    <h1>Halaman Register</h1>
@endsection