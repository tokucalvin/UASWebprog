@extends('main')

@include('header')

@include('navbar')

@section('container')
    <table>
        <tr>
            Tomat
        </tr>
        <tr>
            <td>
                <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/tomatoes-1296x728-feature.jpg" alt="Tomat" width="300" height="200">
            </td>
            <td>
                Rp 3.000,00
                <br>
                Tomat atau rangam (Solanum lycopersicum syn. Lycopersicum esculentum) adalah tumbuhan dari keluarga Solanaceae, tumbuhan asli Amerika Tengah dan Selatan, dari Meksiko sampai Peru. Tomat merupakan tumbuhan siklus hidup singkat, dapat tumbuh setinggi 1 sampai 3 meter. Tumbuhan ini memiliki buah berwarna hijau, kuning, dan merah yang biasa dipakai sebagai sayur dalam masakan atau dimakan secara langsung tanpa diproses. Tomat memiliki batang dan daun yang tidak dapat dikonsumsi karena masih sekeluarga dengan kentang dan terung yang mengadung alkaloid.
                <br>
                <a href="">buy now</a>
            </td>
        </tr>
    </table>
@endsection