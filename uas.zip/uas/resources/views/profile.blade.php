@extends('main')

@include('header')

@include('navbar')

@section('container')
    <table>
        <tr>
            User Profile
        </tr>
        <tr>
            <td>
                <img src="https://cdn1-production-images-kly.akamaized.net/fwRofQtHSSiaKlk4nb3s2kORpTw=/640x853/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/2398072/original/064695400_1541071261-Iqbaal_1.jpg" alt="Dilan" width="200" height="300">
            </td>
            <td>
                Nama : Dilan
                <br>
                Tempat, tanggal lahir : Bandung, 1 Januari 1975
                <br>
                Alamat : Jalan Batu No.5
                <br>
                <a href="">edit profile</a>
            </td>
        </tr>
    </table>
@endsection