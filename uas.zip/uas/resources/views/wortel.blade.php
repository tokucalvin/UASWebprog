@extends('main')

@include('header')

@include('navbar')

@section('container')
    <table>
        <tr>
            Wortel
        </tr>
        <tr>
            <td>
                <img src="https://balidirectstore.com/wp-content/uploads/2019/08/Organic-Baby-Carrot.jpg" alt="Wortel" width="300" height="200">
            </td>
            <td>
                Rp 2.000,00
                <br>
                Wortel (serapan dari bahasa Belanda: wortel) (Daucus carota subsp. sativus) adalah tumbuhan biennial (siklus hidup 12 - 24 bulan) yang menyimpan karbohidrat dalam jumlah besar untuk tumbuhan tersebut berbunga pada tahun kedua. Batang bunga tumbuh setinggi sekitar 1 m, dengan bunga berwarna putih, dan rasa yang manis langu. Bagian yang dapat dimakan dari wortel adalah bagian umbi atau akarnya.
                <br>
                <a href="">buy now</a>
            </td>
        </tr>
    </table>
@endsection