@extends('main')

@include('header')

@section('container')
    <a href="/home">Find and Buy Your Grocery Here !</a>
@endsection