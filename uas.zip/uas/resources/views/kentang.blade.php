@extends('main')

@include('header')

@include('navbar')

@section('container')
    <table>
        <tr>
            Kentang
        </tr>
        <tr>
            <td>
                <img src="http://t1.gstatic.com/licensed-image?q=tbn:ANd9GcR1M89lNmXLBltfEc5TQZJSpcqvZ36vvZyZfpP98EFh-i4Q9X8S8woN6El91b1pZ5Sw" alt="Kentang" width="300" height="200">
            </td>
            <td>
                Price : Rp 2.000,00
                <br>
                Kentang, ubi kentang, ubi belanda, atau ubi benggala adalah tanaman dari suku Solanaceae yang memiliki umbi batang yang dapat dimakan dan disebut "kentang". Umbi kentang sekarang telah menjadi salah satu makanan pokok penting di Eropa walaupun pada awalnya didatangkan dari Amerika Selatan.

Penjelajah Spanyol dan Portugis pertama kali membawa ke Eropa dan mengembangbiakkan tanaman ini.

Tanaman kentang asalnya dari Amerika Selatan dan telah dibudidayakan oleh penduduk di sana sejak ribuan tahun silam. Tanaman ini merupakan herba (tanaman pendek tidak berkayu) semusim dan menyukai iklim yang sejuk. Di daerah tropis cocok ditanam di dataran tinggi.

Bunga sempurna dan tersusun majemuk. Ukuran cukup besar, dengan diameter sekitar 3 cm. Warnanya berkisar dari ungu hingga putih.
                <br>
                <a href="/">buy now</a>
            </td>
        </tr>
    </table>
@endsection