@extends('main')

@include('header')

@include('navbar')

@section('container')
    <table>
        <tr>
            Manggis
        </tr>
        <tr>
            <td>
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Mangosteen1.jpg/1200px-Mangosteen1.jpg" alt="Manggis" width="300" height="200">
            </td>
            <td>
                Rp 10.000,00
                <br>
                Manggis (Garcinia mangostana L.) adalah sejenis pohon hijau abadi dari daerah tropika yang diyakini berasal dari Semenanjung Malaya dan menyebar ke Kepulauan Nusantara. Tumbuh hingga mencapai 7 sampai 25 meter. Buahnya juga disebut manggis, berwarna merah keunguan ketika matang, meskipun ada pula varian yang kulitnya berwarna merah. Buah manggis dalam perdagangan dikenal sebagai "ratu buah", sebagai pasangan durian, si "raja buah". Buah ini mengandung mempunyai aktivitas antiinflamasi dan antioksidan. Sehingga di luar negeri buah manggis dikenal sebagai buah yang memiliki kadar antioksidan tertinggi di dunia.
                <br>
                <a href="">buy now</a>
            </td>
        </tr>
    </table>
@endsection