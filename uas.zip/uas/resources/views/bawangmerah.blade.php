@extends('main')

@include('header')

@include('navbar')

@section('container')
    <table>
        <tr>
            Bawang merah
        </tr>
        <tr>
            <td>
                <img src="https://asset.kompas.com/crops/A1pqv_0Um0AOuA4rMshY5Xg3BAw=/0x0:1000x667/750x500/data/photo/2019/06/06/1393496124.jpg" alt="Bawang merah" width="300" height="200">
            </td>
            <td>
                Rp 5.000,00
                <br>
                Bawang merah (Allium cepa L. var. aggregatum[1]) adalah salah satu bumbu masak utama dunia yang berasal dari Iran, Pakistan, dan pegunungan-pegunungan di sebelah utaranya, tetapi kemudian menyebar ke berbagai penjuru dunia, baik sub-tropis maupun tropis. Wujudnya berupa umbi yang dapat dimakan mentah, untuk bumbu masak, acar, obat tradisional, kulit umbinya dapat dijadikan zat pewarna dan daunnya dapat pula digunakan untuk campuran sayur.[2] Tanaman penghasilnya disebut dengan nama sama.

Bawang merah saat ini dianggap sebagai sebuah varietas dari spesies Allium cepa, spesies yang memuat sejumlah besar varietas bawang yang dikenal dengan nama kolektif bawang bombai.
                <br>
                <a href="">buy now</a>
            </td>
        </tr>
    </table>
@endsection