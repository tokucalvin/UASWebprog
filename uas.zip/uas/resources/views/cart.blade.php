@extends('main')

@include('header')

@include('navbar')

@section('container')
    <h1>Your cart is empty</h1>
@endsection