@extends('main')

@include('header')

@include('navbar')

@section('container')
    <table>
        <tr>
            Bayam
        </tr>
        <tr>
            <td>
                <img src="https://akcdn.detik.net.id/visual/2018/07/11/cc01493c-6a04-4bea-b33d-3be0086c9f09_169.jpeg?w=650" alt="Bayam" width="300" height="200">
            </td>
            <td>
                Rp 7.000,00
                <br>
                Bayam (Amaranthus) adalah tumbuhan yang biasa ditanam untuk dikonsumsi daunnya sebagai sayuran hijau. Tumbuhan ini berasal dari Amerika tropik namun sekarang tersebar ke seluruh dunia. Tumbuhan ini dikenal sebagai sayuran sumber zat besi yang penting bagi tubuh.
                <br>
                <a href="">buy now</a>
            </td>
        </tr>
    </table>
@endsection