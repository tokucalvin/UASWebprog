<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome',[
        "title" => "Welcome"
    ]);
});

Route::get('/register', function () {
    return view('register',[
        "title" => "Register"
    ]);
});

Route::get('/login', function () {
    return view('login', [
        "title" => "Login"
    ]);
});

Route::get('/home', function () {
    return view('home', [
        "title" => "Home"
    ]);
});

Route::get('/kentang', function () {
    return view('kentang', [
        "title" => "Kentang"
    ]);
});

Route::get('/wortel', function () {
    return view('wortel', [
        "title" => "Wortel"
    ]);
});

Route::get('/tomat', function () {
    return view('tomat', [
        "title" => "Tomat"
    ]);
});

Route::get('/kangkung', function () {
    return view('kangkung', [
        "title" => "Kangkung"
    ]);
});

Route::get('/bayam', function () {
    return view('bayam', [
        "title" => "Bayam"
    ]);
});

Route::get('/bawangmerah', function () {
    return view('bawangmerah', [
        "title" => "Bawang Merah"
    ]);
});

Route::get('/pisang', function () {
    return view('pisang', [
        "title" => "Pisang"
    ]);
});

Route::get('/apel', function () {
    return view('apel', [
        "title" => "Apel"
    ]);
});

Route::get('/anggur', function () {
    return view('anggur', [
        "title" => "Anggur"
    ]);
});

Route::get('mangga', function () {
    return view('mangga', [
        "title" => "Mangga"
    ]);
});

Route::get('/manggis', function () {
    return view('manggis', [
        "title" => "Manggis"
    ]);
});

Route::get('/kubis', function () {
    return view('kubis', [
        "title" => "Kubis"
    ]);
});


Route::get('/cart', function () {
    return view('cart', [
        "title" => "Cart"
    ]);
});

Route::get('/profile', function () {
    return view('profile', [
        "title" => "Profile"
    ]);
});